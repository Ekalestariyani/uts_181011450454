package com.example.ust_181011450454

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
